/* 
 * File:   main.cpp
 * Author: bozhin
 *
 * Created on Понеделник, 2012, Юли 9, 0:05
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

