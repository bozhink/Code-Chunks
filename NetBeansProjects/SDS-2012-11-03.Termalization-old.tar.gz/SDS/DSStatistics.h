/*
 * File:   DSDtatistics.h
 * Author: bozhin
 *
 * Created on November 3, 2012, 12:18 PM
 */

#ifndef DSDTATISTICS_H
#define	DSDTATISTICS_H
#include "sdsmodel.h"
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <fstream>
#include <cmath>
#ifndef N_STATISTICS
#define N_STATISTICS 10000000
#endif  /* N_STATISTICS */
#ifndef N_BINS
#define N_BINS 33
#endif /* N_BINS */
#ifndef N_Q_MOMENTS
#define N_Q_MOMENTS 9 /* Number of calculated q-moments */
#endif /* N_Q_MOMENTS */

#define BUFFER_SIZE 8

class DSStatistics
{
    char buf[BUFFER_SIZE];
    fstream f_data_st;
    char*fn_data_st;
    FILE*f_s_histogram;
    char*fn_s_histogram;
    FILE*f_t_histogram;
    char*fn_t_histogram;

    int Lx, Ly; // Lattice sizes
    int Lmax;
    int N; // Size of s-histogram
    int h; // Width of bins of the s-histogram

    int *t; /* Data array to be stored t-histogram */
    int *s; /* Data array to be stored s-histogram */

    int ss, tt;
    int smin, smax;
    int tmin, tmax;
    double t_area, s_area;
    int iarea;

    double s_moments[N_Q_MOMENTS];
    double t_moments[N_Q_MOMENTS];

public:
    DSStatistics(SDSModel*,char*,char*,char*);
    DSStatistics(int,int,char*,char*,char*);
    ~DSStatistics();

    void print_st(SDSModel*);

    void Simulate(SDSModel*);
    void Simulate(SDSModel*, int);
    void Simulate(SDSModel*, int, int);

    void WriteHistograms();

    double Pt(int);
    double Ps(int);
    void Qmoments();

    void Set_st_filename(char*);
    void Set_s_hist_filename(char*);
    void Set_t_hist_filename(char*);

    int Get_smin();
    int Get_smax();
    int Get_tmin();
    int Get_tmax();
    int Get_iarea();
    double Get_sarea();
    double Get_tarea();
    int Get_h();
    int Get_N();
    double*Get_s_moments();
    double*Get_t_moments();
};



#endif	/* DSDTATISTICS_H */

