#include "DSStatistics.h"

#ifdef DSDTATISTICS_H


/*
 * *****************************************************************************
 *
 * Constrictors and destructor
 *
 * *****************************************************************************
 */
DSStatistics::DSStatistics(SDSModel*sds, char*fn_data, char*fn_s, char*fn_t)
{
    sds->GetSize(&Lx, &Ly);
    /*
     * Calculation of h:
     * N_BINS=33 is the integer part of 2*log(10^7)
     * 10*L is a lowered boundary of maximal length of a avalanche
     *      in a lattice of size L
     * 2*(.../2) means that we want h to be even
     */
    Lmax = Lx - ((Lx-Ly) &((Lx-Ly)>>31));
    h=2*((10*Lmax/N_BINS)/2);
    N=Lx*Ly/(3*h);

    // Allocation of memory for histogram arrays
    t = (int*) malloc((Ly+1) * sizeof(int));
    for (int i=0; i<Ly+1; i++) t[i] = 0;
    s = (int*) malloc(N * sizeof(int));
    for (int i=0; i<N; i++) s[i] = 0;

    // Initialization
    smin = 0;
    smax = 0;
    tmin = 0;
    tmax = 0;
    iarea = 0;
    s_area = 0.0;
    t_area = 0.0;
    for (int i=0; i<N_Q_MOMENTS; i++) {
        t_moments[i]=0;
        s_moments[i]=0;
    }

    // Setting file names
    fn_data_st = fn_data;
    fn_s_histogram = fn_s;
    fn_t_histogram = fn_t;
}

DSStatistics::DSStatistics(int lx, int ly, char*fn_data, char*fn_s, char*fn_t)
{
    Lx = lx;
    Ly = ly;
    /*
     * Calculation of h:
     * N_BINS=33 is the integer part of 2*log(10^7)
     * 10*L is a lowered boundary of maximal length of a avalanche
     *      in a lattice of size L
     * 2*(.../2) means that we want h to be even
     */
    Lmax = Lx - ((Lx-Ly) &((Lx-Ly)>>31));
    h=2*((10*Lmax/N_BINS)/2);
    N=Lx*Ly/(3*h);

    // Allocation of memory for histogram arrays
    t = (int*) malloc((Ly+1) * sizeof(int));
    for (int i=0; i<Ly+1; i++) t[i] = 0;
    s = (int*) malloc(N * sizeof(int));
    for (int i=0; i<N; i++) s[i] = 0;

    // Initialization
    smin = 0;
    smax = 0;
    tmin = 0;
    tmax = 0;
    iarea = 0;
    s_area = 0.0;
    t_area = 0.0;
    for (int i=0; i<N_Q_MOMENTS; i++) {
        t_moments[i]=0;
        s_moments[i]=0;
    }

    // Setting file names
    fn_data_st = fn_data;
    fn_s_histogram = fn_s;
    fn_t_histogram = fn_t;
}

DSStatistics::~DSStatistics()
{
    free(s);
    free(t);
    cout << "Deleting Statistics " << endl;
}



/*
 * *****************************************************************************
 *
 * Simulation
 *
 * *****************************************************************************
 */

void DSStatistics::Simulate(SDSModel*sds)
{
    /* Open data file */
    f_data_st.open(fn_data_st, ios::out | ios::trunc | ios::binary);
    if (!f_data_st.is_open()) perror("Error opening ST data file");

    /* Generating data */
    for (int i=0; i<N_STATISTICS; i++)
    {
        sds->NextStep();
        ss = sds->Get_s();
        tt = sds->Get_t();
        sprintf(buf, "%d", tt);
        f_data_st.write(buf, BUFFER_SIZE);
        sprintf(buf, "%d", ss);
        f_data_st.write(buf, BUFFER_SIZE);
        if ( tt < Ly ) {
            t[tt]++;    /* Width of bins is 1 */
            s[ss/h]++;  /* Width of bins is h */
            tmin += ((tt-tmin) & ((tt-tmin) >> 31));
            smin += ((ss-smin) & ((ss-smin) >> 31));
            tmax -= ((tmax-tt) & ((tmax-tt) >> 31));
            smax -= ((smax-ss) & ((smax-ss) >> 31));
            iarea++;
        }
    }

    t_area = (double) iarea;
    s_area = t_area;

    f_data_st.close();
}

void DSStatistics::Simulate(SDSModel*sds, int skip)
{
    /* Open data file */
    f_data_st.open(fn_data_st, ios::out | ios::trunc | ios::binary);
    if (!f_data_st.is_open()) perror("Error opening ST data file");

    /* Generating data */
    for (int i=0; i<N_STATISTICS; i++)
    {
        sds->NextStep(skip);
        ss = sds->Get_s();
        tt = sds->Get_t();
        sprintf(buf, "%d", tt);
        f_data_st.write(buf, BUFFER_SIZE);
        sprintf(buf, "%d", ss);
        f_data_st.write(buf, BUFFER_SIZE);
        if ( tt < Ly ) {
            t[tt]++;    /* Width of bins is 1 */
            s[ss/h]++;  /* Width of bins is h */
            tmin += ((tt-tmin) & ((tt-tmin) >> 31));
            smin += ((ss-smin) & ((ss-smin) >> 31));
            tmax -= ((tmax-tt) & ((tmax-tt) >> 31));
            smax -= ((smax-ss) & ((smax-ss) >> 31));
            iarea++;
        }
    }

    t_area = (double) iarea;
    s_area = t_area;

    f_data_st.close();
}

void DSStatistics::Simulate(SDSModel*sds, int skip, int termalizationTime)
{
    /* Open data file */
    f_data_st.open(fn_data_st, ios::out | ios::trunc | ios::binary);
    if (!f_data_st.is_open()) perror("Error opening ST data file");

    sds->Termalize(termalizationTime);

    /* Generating data */
    for (int i=0; i<N_STATISTICS; i++)
    {
        sds->NextStep(skip);
        ss = sds->Get_s();
        tt = sds->Get_t();
        sprintf(buf, "%d", tt);
        f_data_st.write(buf, BUFFER_SIZE);
        sprintf(buf, "%d", ss);
        f_data_st.write(buf, BUFFER_SIZE);
        if ( tt < Ly ) {
            t[tt]++;    /* Width of bins is 1 */
            s[ss/h]++;  /* Width of bins is h */
            tmin += ((tt-tmin) & ((tt-tmin) >> 31));
            smin += ((ss-smin) & ((ss-smin) >> 31));
            tmax -= ((tmax-tt) & ((tmax-tt) >> 31));
            smax -= ((smax-ss) & ((smax-ss) >> 31));
            iarea++;
        }
    }

    t_area = (double) iarea;
    s_area = t_area;

    f_data_st.close();
}


/*
 * *****************************************************************************
 *
 * Write histograms to file
 *
 * *****************************************************************************
 */

void DSStatistics::WriteHistograms()
{
    /* Open output files to export histograms data */
    if (!(f_s_histogram=fopen(fn_s_histogram, "w"))) perror("Unable to open s_histogram file.");
    if (!(f_t_histogram=fopen(fn_t_histogram, "w"))) perror("Unable to open t_histogram file.");

    /* Writing histogram data to corresponding files */
    for (int i=1; i<Ly; i++) /* i=1 because there is no avalanches of length 0 */
    {
        fprintf(f_t_histogram, "%d %d %lf\n", i, t[i], t[i]/t_area);
        //fflush(f_t_histogram);
    }
    for (int i=0; i<N; i++)
    {
        /*
         * i*h+1 because the first bin corresponds to data from 1 to h, i. e.
         * every bin contains data for s such that
         * i*h+1 <= s <= (i+1)*h.
         *
         * Obviously in the file will be exported left boudaries of every bin
         */
        fprintf(f_s_histogram, "%d %d %lf\n", i*h+1, s[i], s[i]/s_area);
        //fflush(f_s_histogram);
    }
    /* Close histogram files */
    fclose(f_s_histogram);
    fclose(f_t_histogram);
}


void DSStatistics::Set_s_hist_filename(char*fname)
{
    fn_s_histogram = fname;
}
void DSStatistics::Set_t_hist_filename(char*fname)
{
    fn_t_histogram = fname;
}
void DSStatistics::Set_st_filename(char*fname)
{
    fn_data_st = fname;
}



/*
 * *****************************************************************************
 *
 * Probability distributions
 *
 * *****************************************************************************
 */

/*
 * The following function calculates the probability distribution P(t) and
 * returns it value as double.
 *
 * Dummy arguments:
 * int t -- value of t, on which P(t) will be calculated
 * int N -- size of the histogram array; This value is used for validity check:
 *          if t > N-1 then P(t)=-1.0
 * int*t_hist -- array of size N, containing t-histogram
 * double area -- the area of the histogram
 */
double DSStatistics::Pt(int tt) {
    if (tt>=Ly || t<0) {
        return -1.0;
    } else {
        return t[tt]/t_area;
    }
}

/*
 * The following function calculates the probability distribution P(s) and
 * returns it value as double.
 *
 * Dummy arguments:
 * int s -- value of s, on which P(s) will be calculated
 * int N -- size of the histogram array; This value is used for validity check:
 *          if s > N-1 then P(s)=-1.0
 * int*s_hist -- array of size N, containing s-histogram
 * int h -- width of bins of the histogram
 * double area -- the area of the histogram
 */
double DSStatistics::Ps(int ss) {
    if (ss>(N-1)*h || ss <=0) {
        return -1.0;
    } else {
        int i, k;
        for (i=0; i<N-1; i++) {
            if (i*h+1<=ss && ss<=(i+1)*h) {
                k=i;
                break;
            }
        }
        /* Linear approximation to values of Ps */
        return (s[k] + (s[k+1]-s[k])*(1.0/h)*(ss-k*h-1))/s_area;
    }
}


/*
 * *****************************************************************************
 *
 * q-moments
 *
 * *****************************************************************************
 */

/*
 * The following program calculates q-moments of s and t.
 *
 * Dummy arguments:
 * char*file_mane -- name of the file where are stored data points (t,s)
 *                   in format "%d\t%d"
 *
 * int N_t -- size of the array containing the t-histogram
 * int*t_hist -- array containing the t-histogram
 * REM: It is supposed that the width of bins of the t-histogram is 1
 * double t_area -- area of the t-histogram
 *
 * int N_s -- size of the array containing the s-histogram
 * int*s_hist -- array containing the s-histogram
 * int h_s -- width of bins of the s-histogram
 * double s_area -- area of the s-histogram
 *
 * int N_moments -- size of t_moments & s_moments arrays; number of moments
 *                  to be calculated
 * double*t_moments -- array, in which t-moments will be stored
 * double*s_moments -- array, in which s-moments will be stored
 */
void DSStatistics::Qmoments()
{
    /* Open data file */
    f_data_st.open(fn_data_st, ios::in | ios::binary | ios::ate);
    if (!f_data_st.is_open()) perror("q_moments: Error opening data file");
    f_data_st.seekg(0, ios::beg);

    /* Reading data */
    while(!f_data_st.eof())
    {
        f_data_st.read(buf, BUFFER_SIZE);
        tt = atoi(buf);
        f_data_st.read(buf, BUFFER_SIZE);
        ss = atoi(buf);
        if ( tt < Ly ) {
            iarea++;
            for (int i=0; i<N_Q_MOMENTS; i++)
            {
                t_moments[i] += pow(1.0*tt, 1.0*(i+1)) * Pt(tt);
                s_moments[i] += pow(1.0*ss, 1.0*(i+1)) * Ps(ss);
            }
        }
    }
    for (int i=0; i<N_Q_MOMENTS; i++) {
        t_moments[i] = log(t_moments[i]/t_area);
        s_moments[i] = log(s_moments[i]/s_area);
    }
    f_data_st.close();
}





/*
 * *****************************************************************************
 *
 * Data obtaining functions
 *
 * *****************************************************************************
 */

int DSStatistics::Get_smin() {
    return smin;
}
int DSStatistics::Get_smax() {
    return smax;
}
int DSStatistics::Get_tmin() {
    return tmin;
}
int DSStatistics::Get_tmax() {
    return tmax;
}
int DSStatistics::Get_iarea() {
    return iarea;
}
double DSStatistics::Get_sarea() {
    return s_area;
}
double DSStatistics::Get_tarea() {
    return t_area;
}
int DSStatistics::Get_h() {
    return h;
}
int DSStatistics::Get_N() {
    return N;
}

double *DSStatistics::Get_t_moments()
{
    return t_moments;
}

double *DSStatistics::Get_s_moments()
{
    return s_moments;
}


/*
 * *****************************************************************************
 *
 * Other functions
 *
 * *****************************************************************************
 */


void DSStatistics::print_st(SDSModel* sds)
{
    sds->GetSize(&Lx, &Ly);
    sds->NextStep(Lx);
    cout << "s=" << sds->Get_s() << "\tt=" << sds->Get_t() <<endl;
}

#endif 	/* DSDTATISTICS_H */
