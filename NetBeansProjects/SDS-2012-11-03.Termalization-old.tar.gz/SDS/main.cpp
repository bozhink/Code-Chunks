/*
 * File:   main.cpp
 * Author: bozhin
 *
 * Created on November 3, 2012, 9:54 AM
 */

#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <iostream>
#include <fstream>

#define N_Q_MOMENTS 9

#include "sdsmodel.h"
#include "DSStatistics.h"


using namespace std;

#define F_DATA_ST "s_t"
#define F_S_HIST "s_hist-200-0"
#define F_T_HIST "t_hist-200-0"
#define F_S_MOMENTS "s_moments"
#define F_T_MOMENTS "t_moments"

/*
 *
 */
int main(int argc, char** argv)
{
    if (argc < 4)
    {
        cerr << "Usage: " << argv[0] << " <L> <s-histogram file> <t-histogram file>"<<endl;
        return 1;
    }

    char*fn_s_histogram = argv[2];
    char*fn_t_histogram = argv[3];

    double*s_moments;
    double*t_moments;
    fstream f_s_moments;
    fstream f_t_moments;


    int L = atoi(argv[1]);
    DSStatistics stat(L, L, F_DATA_ST, fn_s_histogram, fn_t_histogram);
    if (1)
    {
        SDSModel sdsmodel(L);
        cout << "Termalization ..." << endl;
        sdsmodel.Termalize();
        cout << "Simulation ..." << endl;
        stat.Simulate(&sdsmodel);
        cout << "Writing histogram files ..."<<endl;
        stat.WriteHistograms();
    }

    cout << endl;
    cout << "S-histogram stride h=" << stat.Get_h() << endl;
    cout << "S-histogram size   N=" << stat.Get_N() << endl;
    cout << endl;
    cout << "smin = " << stat.Get_smin() << "\tsmax = " << stat.Get_smax() <<endl;
    cout << "tmin = " << stat.Get_tmin() << "\ttmax = " << stat.Get_tmax() <<endl;
    cout << "s-area = " << stat.Get_sarea() << endl;
    cout << "t-area = " << stat.Get_tarea() << endl;
    cout << "i-area = " << stat.Get_iarea() << endl;

    cout << endl;
    cout << "Calculating q-moments ..." << endl;
    stat.Qmoments();

    f_s_moments.open(F_S_MOMENTS, ios::out | ios::app);
    if (!f_s_moments.is_open()) perror ("Unable to open s-moments output file");
    f_t_moments.open(F_T_MOMENTS, ios::out | ios::app);
    if (!f_t_moments.is_open()) perror ("Unable to open t-moments output file");

    s_moments = stat.Get_s_moments();
    t_moments = stat.Get_t_moments();

    cout << "Writing q-moments ..." << endl;

    f_s_moments << L << " " << log(L) << " ";
    f_t_moments << L << " " << log(L) << " ";
    for (int i=0; i<N_Q_MOMENTS; i++)
    {
        f_s_moments << " " << s_moments[i];
        f_t_moments << " " << t_moments[i];
    }
    f_s_moments << endl;
    f_t_moments << endl;

    f_s_moments.close();
    f_t_moments.close();


    cout << "END" << endl;
    return 0;
}

