/*
 * File:   sdsmodel.h
 * Author: bozhin
 *
 * Created on November 3, 2012, 9:55 AM
 */

#ifndef SDSMODEL_H
#define	SDSMODEL_H
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <iostream>


#define Z_CRITICAL 2

using namespace std;


class SDSModel {
    int s; // Size of the avalanche
    int t; // Length of the avalanche
    int**main_matrix; // Spin Matrix
    int Lx, Ly; // Sizes of the matrix
    int Lmiddle; // Half of Lx
    void update(int, int); // Updates matrix without updating values for s ant t
    void st_update(int, int); // Updates matrix and the values of s and t
    int**malloc2d(int, int); // Allocate memory for 2D array
    void free2d(int**,int,int); // Free moemory of 2D array
public:
    SDSModel();
    SDSModel(int);
    SDSModel(int,int);
    ~SDSModel();
    int Get_s();
    int Get_t();
    void GetSize(int*,int*);
    void Termalize();
    void Termalize(int);
    void NextStep();
    void NextStep(int);
};


#endif	/* SDSMODEL_H */

