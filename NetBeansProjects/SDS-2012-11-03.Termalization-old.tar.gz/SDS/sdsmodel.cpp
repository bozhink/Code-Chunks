#include "sdsmodel.h"

#ifdef SDSMODEL_H

int **SDSModel::malloc2d(int r, int c)
{
    int **t = (int**) malloc(r * sizeof(int*));
    for (int i=0; i<r; i++)
    {
        t[i] = (int *) malloc(c * sizeof(int));
    }
    return t;
}

void SDSModel::free2d(int**t, int r, int c)
{
    for (int i=0; i<r; i++)
    {
        free(t[i]);
    }
    free(t);
}

/*
 * *****************************************************************************
 *
 * Constrictors and destructor
 *
 * *****************************************************************************
 */

SDSModel::SDSModel ()
{
    srand(time(NULL));
    s=0;
    t=0;
    Lx=100;
    Ly=100;
    Lmiddle=Lx/2;
    main_matrix = malloc2d(Lx,Ly);
    for (int i=0; i<Lx; i++)
    {
        for (int j=0; j<Ly; j++)
        {
            main_matrix[i][j] = 0;
        }
    }
    cerr << "Created SDSModel with sizes " << Lx << " by " << Ly << endl;
}

SDSModel::SDSModel (int latticeSize)
{
    srand(time(NULL));
    s=0;
    t=0;
    Lx=latticeSize;
    Ly=latticeSize;
    Lmiddle=Lx/2;
    main_matrix = malloc2d(Lx,Ly);
    for (int i=0; i<Lx; i++)
    {
        for (int j=0; j<Ly; j++)
        {
            main_matrix[i][j] = 0;
        }
    }
    cerr << "Created SDSModel with sizes " << Lx << " by " << Ly << endl;
}

SDSModel::SDSModel (int latticeSizeX, int latticeSizeY)
{
    srand(time(NULL));
    s=0;
    t=0;
    Lx=latticeSizeX;
    Ly=latticeSizeY;
    Lmiddle=Lx/2;
    main_matrix = malloc2d(Lx,Ly);
    for (int i=0; i<Lx; i++)
    {
        for (int j=0; j<Ly; j++)
        {
            main_matrix[i][j] = 0;
        }
    }
    cerr << "Created SDSModel with sizes " << Lx << " by " << Ly << endl;
}

SDSModel::~SDSModel()
{
    free2d(main_matrix, Lx, Ly);
    cerr << "Deleted SDSModel with size " << Lx << " by " << Ly << endl;
}

/*
 * *****************************************************************************
 *
 * Update mathods
 *
 * *****************************************************************************
 */

void SDSModel::update (int x, int y)
{
    if (main_matrix[x][y] >= Z_CRITICAL)  /* toppling */
    {
        main_matrix[x][y] -= 2;

        if (y>=Ly) {
            return; /* Open boudary condition */
        } else {
            /* Our grain of energy is not on the boundary */
            /* Here goes stochatic part */
            /* Nonexclusive, NESDS */
            int k1 = rand() % 3 - 1; /* One of the three neighbours */
            int k2 = rand() % 3 - 1; /* One of the three neighbours */

            int x1 = (x+k1+Lx) % Lx; /* Periodic boundary conditions */
            int x2 = (x+k2+Lx) % Lx; /* Periodic boundary conditions */
            y++;

            main_matrix[x1][y]++;
            main_matrix[x2][y]++;

            update(x1, y);
            update(x2, y);
        }
    }
    //printf("Update: x=%d\ty=%d\tt=%d\ts=%d\n", x, y, t, s);
}


void SDSModel::st_update (int x, int y)
{
    t -= ((t-y) & ((t-y)>>31)); /* Updating t: t=max(t,y) */

    if (main_matrix[x][y] >= Z_CRITICAL)  /* toppling */
    {
        s++; /* If there is toppling then size s is incremented */

        main_matrix[x][y] -= 2;

        if (y>=Ly) {
            return; /* Open boudary condition */
        } else {
            /* Our grain of energy is not on the boundary */
            /* Here goes stochatic part */
            /* Nonexclusive, NESDS */
            int k1 = rand() % 3 - 1; /* One of the three neighbours */
            int k2 = rand() % 3 - 1; /* One of the three neighbours */

            int x1 = (x+k1+Lx) % Lx; /* Periodic boundary conditions */
            int x2 = (x+k2+Lx) % Lx; /* Periodic boundary conditions */
            y++;

            main_matrix[x1][y]++;
            main_matrix[x2][y]++;

            st_update(x1, y);
            st_update(x2, y);
        }
    }
    //printf("Update: x=%d\ty=%d\tt=%d\ts=%d\n", x, y, t, s);
}

/*
 * *****************************************************************************
 *
 * Data obtaining functions
 *
 * *****************************************************************************
 */

int SDSModel::Get_s()
{
    return s;
}

int SDSModel::Get_t()
{
    return t;
}

void SDSModel::GetSize(int *X, int *Y)
{
    *X = Lx;
    *Y = Ly;
}


/*
 * *****************************************************************************
 *
 * Next Step functions
 *
 * *****************************************************************************
 */

void SDSModel::NextStep()
{
    s=0;
    t=0;
    main_matrix[Lmiddle][0] = Z_CRITICAL;
    st_update(Lmiddle, 0);
}

void SDSModel::NextStep(int skip)
{
    for (int i=0; i<skip; i++)
    {
        main_matrix[Lmiddle][0] = Z_CRITICAL;
        update(Lmiddle, 0);
    }
    NextStep();
}


/*
 * *****************************************************************************
 *
 * Termalization functions
 *
 * *****************************************************************************
 */

void SDSModel::Termalize(int termalizationTime)
{
    for (int i=0; i<termalizationTime; i++)
    {
        main_matrix[Lmiddle][0] = Z_CRITICAL;
        update(Lmiddle, 0);
    }
}

void SDSModel::Termalize()
{
    int termalizationTime = Lx*Ly;
    Termalize(termalizationTime);
}

#endif /* SDSMODEL_H */
