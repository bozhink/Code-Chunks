package btwsandpile;

import btw.BTWModel;
import java.io.*;

/**
 *
 * @author bozhin
 */
public class BTWSandPile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        int nx = 51, ny = 51;
        int hx = 10, hy = 10;
        
        int maxIterations = 9000;
        BTWModel sandPile = new BTWModel(nx, ny);
        
        String line=null;
        String fname=null;
        
        for (int i=0; i<maxIterations; i++)
        {
            FileOutputStream fout=null;
            try
            {
                
                if (i<10)
                {
                    fname = "btw-000"+i+".txt";
                }
                else if (i<100)
                {
                    fname = "btw-00"+i+".txt";
                }
                else if (i<1000)
                {
                    fname = "btw-0"+i+".txt";
                    
                }
                else
                {
                    fname = "btw-"+i+".txt";
                }
                fout = new FileOutputStream(fname);
            }
            catch (FileNotFoundException e)
            {
                System.err.println("Error opening fil #"+i);
            }
            
            System.err.println(fname);
            
            sandPile.Update();
            try
            {
                for (int x=0; x<nx; x++)
                {
                    for (int y=0; y<ny; y++)
                    {
                        line = Integer.toString(x*hx) + "\t" +
                                Integer.toString(y*hy) + "\t" +
                                Integer.toString(hx) + "\t" +
                                Integer.toString(hy) + "\t" +
                                Integer.toString(sandPile.matrix[x][y]) +"\n";
                        fout.write(line.getBytes());
                    }
                }
            }
            catch (IOException e)
            {
                System.err.println("Error writing to file #"+i);
            }
            try 
            {
                fout.close();
            } 
            catch (IOException ex) 
            {
                
            }
        }
    }
}
