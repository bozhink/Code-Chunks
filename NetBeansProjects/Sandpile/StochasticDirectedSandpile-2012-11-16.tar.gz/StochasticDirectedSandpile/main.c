/*
 * File:   main.c
 * Author: bozhin
 *
 * Created on October 31, 2012, 9:44 PM
 */

#define SKIP 0
#define L_MAX 4800
/* File name format: s_t-<L>-<skip> */
#define DATA_ST_FILE "s_t-4800-0"
#define N_STATISTICS 10000000
#include "sds.h"
#include <time.h>

/*
 *
 */
int main(int argc, char** argv) {
    int i, j;
    /* Initialization */
    for (i=0; i<L_MAX; i++) {
        for (j=0;j<L_MAX; j++) {
            main_matrix[i][j]=0;
        }
    }
    /* Initialization of Random Number Generator */
    srand(time(NULL));

    /* Termalization */
    for (i=0; i<L_MAX*L_MAX; i++) {
        next_step();
        //printf("i %d\ts %d\tt %d\n",i,s,t);
    }

    /* Open dat file */
    f_data_st = fopen(DATA_ST_FILE,"w");
    if (!f_data_st) {
        fprintf(stderr, "Error opening ST data file");
        return (EXIT_FAILURE);
    }

    /* Generating data */
    for (i=0; i<N_STATISTICS; i++) {
        for (j=0; j<SKIP; j++) {
            next_step();
        }
        next_step();
        fprintf(f_data_st, "%d\t%d\n",t,s);
    }

    fclose(f_data_st);

    return (EXIT_SUCCESS);
}

