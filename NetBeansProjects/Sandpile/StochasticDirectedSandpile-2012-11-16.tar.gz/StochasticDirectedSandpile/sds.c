#include "sds.h"

void next_step() {
    s=0;
    t=0;
    main_matrix[L_MAX/2][0]=2;
    update(L_MAX/2, 0);
}

void update (int x, int y) {


    t -= ((t-y) & ((t-y)>>31)); /* Updating t: t=max(t,y) */

    if (main_matrix[x][y] >= Z_CRITICAL)  /* toppling */
    {
        s++; /* If there is toppling then size s is incremented */

        main_matrix[x][y] -= 2;

        if (y>=L_MAX) {
            return; /* Open boudary condition */
        } else {
            /* Our grain of energy is not on the boundary */
            /* Here goes stochatic part */
            /* Nonexclusive, NESDS */
            int k1 = rand() % 3 - 1; /* One of the three neighbours */
            int k2 = rand() % 3 - 1; /* One of the three neighbours */

            int x1 = (x+k1+L_MAX) % L_MAX; /* Periodic boundary conditions */
            int x2 = (x+k2+L_MAX) % L_MAX; /* Periodic boundary conditions */

            main_matrix[x1][y+1]++;
            main_matrix[x2][y+1]++;

            update(x1, y+1);
            update(x2, y+1);
        }
    }
    //printf("Update: x=%d\ty=%d\tt=%d\ts=%d\n", x, y, t, s);
}
