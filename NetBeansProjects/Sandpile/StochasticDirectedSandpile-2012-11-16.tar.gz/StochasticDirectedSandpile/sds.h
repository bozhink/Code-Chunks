/*
 * File:   sds.h
 * Author: bozhin
 *
 * Created on October 31, 2012, 9:52 PM
 */

#include <stdio.h>
#include <stdlib.h>

#ifndef SDS_H
#define	SDS_H
#ifndef L_MAX /* Maximal value of L */
#define L_MAX 100
#endif /* L_MAX */
#ifndef N_STATISTICS /* Number of avalanches to observe */
#define N_STATISTICS 10000000
#endif /* N_STATISTICS */
#ifndef DATA_ST_FILE /* File name to write s and t parameters */
#define DATA_ST_FILE "s_t"
#endif /* DATA_ST_FILE */
#ifndef AVALANCHE_CONTAINER_FILE /* File to write coordinates of currenet avalanche */
#define AVALANCHE_CONTAINER_FILE "avalanche_container"
#endif /* AVALANCHE_CONTAINER_FILE */
#ifndef Z_CRITICAL /* Critical value of z */
#define Z_CRITICAL 2
#endif /* Z_CRITICAL */



int main_matrix[L_MAX][L_MAX]; /* Matrix containing model's lattice */

FILE*f_data_st; /* File to write s and t parameters */
FILE*f_avalache_container; /* File to write coordinates of current avalanche */

int s; /* s-parameter of current avalanche */
int t; /* t-parameter of current avalanche */




void next_step();
void update(int, int);
#endif	/* SDS_H */

