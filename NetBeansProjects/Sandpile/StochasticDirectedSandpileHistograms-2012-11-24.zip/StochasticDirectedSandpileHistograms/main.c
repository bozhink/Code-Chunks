/*
 * File:   main.c
 * Author: bozhin
 *
 * Created on November 1, 2012, 1:48 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N_STATISTICS 10000000
#define N_BINS 33
#define L_MAX 6400
#define N_MAX (L_MAX*L_MAX/30)
#define N_Q_MOMENTS 9 /* Number of calculated q-moments */


double s_moments[N_Q_MOMENTS];
double t_moments[N_Q_MOMENTS];

double Pt(int, int, int*, double);
double Ps(int, int, int*, int, double);

void q_moments(char*,int,int*,double,int,int*,int,double,int,double*,double*);

/*
 *
 */
int main(int argc, char** argv) {
    FILE*f_data_st;
    char*fn_data_st;
    FILE*f_s_histogram;
    char*fn_s_histogram;
    FILE*f_t_histogram;
    char*fn_t_histogram;
    FILE*f_moments;
    char*fn_moments;

    int t[L_MAX+1]; /* Data array to be stored t-histogram */
    int s[N_MAX]; /* Data array to be stored s-histogram */

    int i, j;
    int L; /* Current latice size */
    int N; /* Current size of s-histogram array */
    int h; /* Width of bins of the s-histogram */

    int ss, tt;
    int smin=0, smax=0;
    int tmin=0, tmax=0;
    double t_area=0.0;
    double s_area=0.0;
    int iarea=0;


    if (argc < 6) {
        printf("Usage: %s <L> <s-t> <t-hist> <s-hist> <moments>\n", argv[0]);
        printf("   Where:\n");
        printf("      L       =  lattice size\n");
        printf("      s-t     =  s-t data file name\n");
        printf("      t-hist  =  file name of output file to store t-histogram data\n");
        printf("      s-hist  =  file name of output file to store s-histogram data\n");
        printf("      moments =  file name of output file to store moments data\n");
        return 1;
    }

    /* Obtaining input information */
    L = atoi(argv[1]);
    if (L > L_MAX) {
        fprintf(stderr, "Lattice size must not exceeds 6400\n");
        return 2;
    }
    fn_data_st = argv[2];
    fn_t_histogram = argv[3];
    fn_s_histogram = argv[4];
    fn_moments = argv[5];

    /*
     * Calculation of h:
     * N_BINS=33 is the integer part of 2*log(10^7)
     * 10*L is a lowered boundary of maximal length of a avalanche
     *      in a lattice of size L
     * 2*(.../2) means that we want h to be even
     */
    h=2*((10*L/N_BINS)/2);
    printf("h=%d\n",h);
    N=L*L/(3*h);

    /* Initialization of working arrays */
    for (i=0; i<N_MAX; i++) {
        s[i]=0;
    }
    for (i=0; i<L_MAX+1; i++) {
        t[i]=0;
    }
    for (i=0; i<N_Q_MOMENTS; i++) {
        s_moments[i]=0;
        t_moments[i]=0;
    }

    /* Open input data file */
    f_data_st = fopen(fn_data_st, "r");
    if (!f_data_st) {
        perror("Unable to open input data file");
    }

    /* Rading data from input data file */
    while (!feof(f_data_st)) {
        fscanf(f_data_st, "%d\t%d", &tt, &ss);
        if ( tt < L ) {
            t[tt]++;    /* Width of bins is 1 */
            s[ss/h]++;  /* Width of bins is h */
            tmin += ((tt-tmin) & ((tt-tmin) >> 31));
            smin += ((ss-smin) & ((ss-smin) >> 31));
            tmax -= ((tmax-tt) & ((tmax-tt) >> 31));
            smax -= ((smax-ss) & ((smax-ss) >> 31));
            iarea++;
        }
    }
    /* Close input data file */
    fclose(f_data_st);

    t_area = (double) iarea;
    s_area = t_area;
    /* Writing some statistics to console */
    printf("s_min=%d\ts_max=%d\n", smin, smax);
    printf("s_area=%lf\n", s_area);
    printf("t_min=%d\tt_max=%d\n", tmin, tmax);
    printf("t_area=%lf\n", t_area);

    /* Open output files to export histograms data */
    if (!(f_s_histogram=fopen(fn_s_histogram, "w"))) {
        perror("Unable to open s_histogram file.");
    }
    if (!(f_t_histogram=fopen(fn_t_histogram, "w"))) {
        perror("Unable to open t_histogram file.");
    }

    /* Writing histogram data to corresponding files */
    for (i=1; i<L; i++) /* i=1 because there is no avalanches of length 0 */
    {
        fprintf(f_t_histogram, "%d\t%d\t%lf\n", i, t[i], t[i]/t_area);
        //fflush(f_t_histogram);
    }
    for (i=0; i<N; i++)
    {
        /*
         * i*h+1 because the first bin corresponds to data from 1 to h, i. e.
         * every bin contains data for s such that
         * i*h+1 <= s <= (i+1)*h.
         *
         * Obviously in the file will be exported left boudaries of every bin
         */
        fprintf(f_s_histogram, "%d\t%d\t%lf\n", i*h+1, s[i], s[i]/s_area);
        //fflush(f_s_histogram);
    }
    /* Close histogram files */
    fclose(f_s_histogram);
    fclose(f_t_histogram);

    /*
     * Calculation of the lograrithms of q-moments for t and s,
     * where q = 1, ..., N_Q_MOMENTS
     */
    q_moments(fn_data_st, L, t, t_area, N, s, h, s_area, N_Q_MOMENTS, t_moments, s_moments);

    /* Open q-moments data file */
    if (!(f_moments = fopen(fn_moments, "w"))) {
        perror("Cannot open file to write q-moments data");
    }

    /*
     * Writing q-moments data
     * in format:
     * [q-moment] [log(<t^q>_L)] [log(<s^q>_L)]
     */
    for (i=0; i<N_Q_MOMENTS; i++) {
        fprintf(f_moments, "%d\t%lf\t%lf\n", i+1, t_moments[i], s_moments[i]);
        //fflush(f_moments);
    }
    /* Close q-moments file */
    fclose(f_moments);



    return (EXIT_SUCCESS);
}

/*
 * The following function calculates the probability distribution P(t) and
 * returns it value as double.
 *
 * Dummy arguments:
 * int t -- value of t, on which P(t) will be calculated
 * int N -- size of the histogram array; This value is used for validity check:
 *          if t > N-1 then P(t)=-1.0
 * int*t_hist -- array of size N, containing t-histogram
 * double area -- the area of the histogram
 */
double Pt(int t, int N, int*t_hist, double area) {
    if (t>=N || t<0) {
        return -1.0;
    } else {
        return t_hist[t]/area;
    }
}

/*
 * The following function calculates the probability distribution P(s) and
 * returns it value as double.
 *
 * Dummy arguments:
 * int s -- value of s, on which P(s) will be calculated
 * int N -- size of the histogram array; This value is used for validity check:
 *          if s > N-1 then P(s)=-1.0
 * int*s_hist -- array of size N, containing s-histogram
 * int h -- width of bins of the histogram
 * double area -- the area of the histogram
 */
double Ps(int s, int N, int*s_hist, int h, double area) {
    if (s>(N-1)*h || s <=0) {
        return -1.0;
    } else {
        int i, k;
        for (i=0; i<N-1; i++) {
            if (i*h+1<=s && s<=(i+1)*h) {
                k=i;
                break;
            }
        }
        /* Linear approximation to values of Ps */
        return (s_hist[k] + (s_hist[k+1]-s_hist[k])*(1.0/h)*(s-k*h-1))/area;
    }
}


/*
 * The following program calculates q-moments of s and t.
 *
 * Dummy arguments:
 * char*file_mane -- name of the file where are stored data points (t,s)
 *                   in format "%d\t%d"
 *
 * int N_t -- size of the array containing the t-histogram
 * int*t_hist -- array containing the t-histogram
 * REM: It is supposed that the width of bins of the t-histogram is 1
 * double t_area -- area of the t-histogram
 *
 * int N_s -- size of the array containing the s-histogram
 * int*s_hist -- array containing the s-histogram
 * int h_s -- width of bins of the s-histogram
 * double s_area -- area of the s-histogram
 *
 * int N_moments -- size of t_moments & s_moments arrays; number of moments
 *                  to be calculated
 * double*t_moments -- array, in which t-moments will be stored
 * double*s_moments -- array, in which s-moments will be stored
 */
void q_moments(char*file_name,
               int N_t, int*t_hist, double t_area,
               int N_s, int*s_hist, int h_s, double s_area,
               int N_moments, double*t_moments, double*s_moments) {
    /* Open data file */
    FILE*f_st_data = fopen(file_name,"r");
    if (!f_st_data) {
        perror("q_moments: Error opening data file");
    }
    /* Initialization of arrays */
    int i;
    for (i=0; i<N_moments; i++) {
        t_moments[i]=0;
        s_moments[i]=0;
    }
    /* Reading data */
    int tt, ss;
    double t, s;
    long iarea=0;
    while(!feof(f_st_data)) {
        fscanf(f_st_data, "%d\t%d", &tt, &ss);
        if ( tt < N_t ) {
            iarea++;
            for (i=0; i<N_moments; i++) {
                t=pow(1.0*tt, 1.0*(i+1)) * Pt(tt, N_t, t_hist, t_area);
                s=pow(1.0*ss, 1.0*(i+1)) * Ps(ss, N_s, s_hist, h_s, s_area);
                t_moments[i] += t;
                s_moments[i] += s;
            }
        }
    }
    for (i=0; i<N_moments; i++) {
        t_moments[i] = log(t_moments[i]/t_area);
        s_moments[i] = log(s_moments[i]/s_area);
    }
    fclose(f_st_data);

    /*
     * Here goes some debug information:
     * it will be printed the histogram area as
     * a check if data file has be read correctly
     */
    printf("q_moments: iarea=%ld\n",iarea);
}

