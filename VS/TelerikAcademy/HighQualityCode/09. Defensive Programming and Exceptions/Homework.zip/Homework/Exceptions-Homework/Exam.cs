﻿public abstract class Exam
{
    public abstract ExamResult Check();
}
